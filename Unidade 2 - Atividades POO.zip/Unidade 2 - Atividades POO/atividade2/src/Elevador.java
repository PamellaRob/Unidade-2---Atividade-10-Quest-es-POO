public class Elevador {
    int andarAtual;
    int totalAndares;

    void subir(){
        if (andarAtual < totalAndares) {
            andarAtual = andarAtual + 1;
        } else {
            System.out.println("Não é possível subir mais");
        }
    }

    void descer(){
        if (andarAtual > 0) {
            andarAtual = andarAtual - 1;
        } else {
            System.out.println("Não é possível descer mais");
        }
    }
}
