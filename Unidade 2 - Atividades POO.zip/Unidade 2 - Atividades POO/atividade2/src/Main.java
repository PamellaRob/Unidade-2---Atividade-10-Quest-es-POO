public class Main {
    public static void main(String[] args) throws Exception {
        Elevador elevador = new Elevador ();

        elevador.andarAtual = 2;
        elevador.totalAndares = 4;

        elevador.subir();
        System.err.println("Você está no " + elevador.andarAtual + " andar");

        elevador.subir();
        elevador.subir();

        elevador.descer();
        elevador.descer();
        elevador.descer();

        System.err.println("Você está no " + elevador.andarAtual + " andar");
        elevador.descer();
        elevador.descer();
    }
}
