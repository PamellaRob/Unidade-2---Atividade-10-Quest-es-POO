public class Guerreiro {
    int vida;
    int escudo;

    void receberDano (int pontos){
        if (escudo>=pontos) {
            escudo = escudo - pontos;
        } else {
            pontos = pontos - escudo;
            vida = vida - pontos;
            escudo = 0;
        }

        if (vida < 0) {
            System.err.println("Guerreiro está sem vida");
            vida = 0;
        }
    }
}