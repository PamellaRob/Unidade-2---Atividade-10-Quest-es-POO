public class Main {
    public static void main(String[] args) throws Exception {
        Guerreiro guerreiro = new Guerreiro();
        guerreiro.vida = 100;
        guerreiro.escudo = 50;
        

        guerreiro.receberDano(80);

        System.err.println("Oh não! Guerreiro Recebeu Danos...");
        System.err.println("Vida restante: " + guerreiro.vida);
        System.err.println("Escudo restante: " + guerreiro.escudo);
    }
}

