public class Main {
    public static void main(String[] args) throws Exception {
           Video video1 = new Video();
           video1.titulo = "Video Aula Java POO";
           video1.duracao=20;
           video1.estaDandoPlay=true;

           Video video2 = new Video();
           video2.titulo = "Minecraft";
           video2.duracao = 15;
           video2.estaDandoPlay = false;

        if (video1.estaDandoPlay == true) {
            System.out.println("Video 1: " + video1.titulo + " está pausado");
        } else {
            System.out.println("Video 1: " + video1.titulo + "está rodando");
        }

        if (video2.estaDandoPlay == true) {
            System.out.println("Video 2: " + video2.titulo + " está pausado");
        } else {
            System.out.println("Video 2: " + video2.titulo + " está rodando");
        }
}
}


