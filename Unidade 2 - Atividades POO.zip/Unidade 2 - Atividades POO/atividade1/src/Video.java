public class Video {
    String titulo;
    int duracao;
    boolean estaDandoPlay; 
    
    
    void estaDandoPlay() {
        estaDandoPlay = !estaDandoPlay;
    }
}