public class Pet {
    int fome;

    void alimentar(){
        System.err.println("Alimentando...");
        fome = fome - 10;

        if (fome < 0) {
            fome = 0;
        }
    }
}
