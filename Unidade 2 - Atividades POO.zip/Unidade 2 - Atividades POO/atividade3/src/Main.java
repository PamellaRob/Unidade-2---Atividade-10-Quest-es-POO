public class Main {
    public static void main(String[] args) throws Exception {
        Pet gato = new Pet();
        gato.fome = 5;

        gato.alimentar();

        System.err.println("Nível de fome do seu Pet: " + gato.fome);


        /* EXEMPLO COM FOME 100
        
        Pet gato = new Pet();
        gato.fome = 100;

        gato.alimentar();

        System.err.println("Nível de fome do seu Pet: " + gato.fome);

        gato.alimentar();
        gato.alimentar();
        
        System.err.println("Nível de fome do seu Pet: " + gato.fome); */
    }
}
