public class Main {
    public static void main(String[] args) throws Exception {
        ContaBancaria conta = new ContaBancaria();
        conta.saldo=300;
        conta.cliente = "Ryan";

        boolean resultadosaque = conta.sacar(420);

        if (resultadosaque == true) {
            System.err.println(conta.cliente + " seu saque foi realizado com sucesso! ");
            System.err.println("Saldo atual: R$" + conta.saldo);
        } else {
            System.err.println("Saldo Insuficiente!");
            System.err.println("Saldo disponível: R$" + conta.saldo);
        }


    }
}
