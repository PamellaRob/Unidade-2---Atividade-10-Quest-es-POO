public class ContaBancaria {
    double saldo;
    String cliente;

    boolean sacar(double valor){
        if (valor<=saldo) {
            saldo = saldo - valor;
            return true;
        } else {
            return false;
        }
    }
    
}
