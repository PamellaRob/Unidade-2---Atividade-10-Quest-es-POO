public class Main {
    public static void main(String[] args) {
        cliente cliente = new cliente();
        cliente.tipo = 1; // VIP

        Cupom cupom = new Cupom();
        cupom.codigo = 1; // CONSUMIDOR20
        cupom.usosRestantes = 1;

        Compra compra = new Compra();
        compra.valorTotal = 100;

        ProcessadorVendas processador = new ProcessadorVendas();

        processador.processar(cliente, compra, cupom);

        System.err.println("Segunda tentativa...");

        processador.processar(cliente, compra, cupom);
    }
}