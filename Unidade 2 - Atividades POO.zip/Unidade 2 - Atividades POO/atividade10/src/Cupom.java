public class Cupom {
    int codigo; // 1 = CONSUMIDOR20
    int usosRestantes;

    boolean validarCupom() {

        if (codigo == 1 && usosRestantes > 0) {
            usosRestantes--;
            return true;
        }

        return false;
    }
}