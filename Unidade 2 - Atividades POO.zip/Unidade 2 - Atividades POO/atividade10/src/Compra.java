public class Compra {
    double valorTotal;
}