public class cliente {
    int tipo; // 1 = VIP 2 = Normal
}