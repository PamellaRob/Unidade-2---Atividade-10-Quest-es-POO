public class ProcessadorVendas{
    void processar(cliente cliente, Compra compra, Cupom cupom) {

        double valorFinal = compra.valorTotal;
        double desconto = 0;

        // desconto no cliente VIP
        if (cliente.tipo == 1) {
            desconto = valorFinal * 0.05;
            valorFinal = valorFinal - desconto;
        }

        // desconto cupom
        if (cupom.validarCupom()) {
            valorFinal = valorFinal - 20;
            desconto = desconto + 20;
        }

        System.out.println("Valor original da compra: R$ " + compra.valorTotal);
        System.out.println("Desconto aplicado: R$ " + desconto);
        System.out.println("Valor final da compra: R$ " + valorFinal);
    }
}