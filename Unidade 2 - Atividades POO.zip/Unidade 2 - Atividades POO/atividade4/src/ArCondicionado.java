public class ArCondicionado {
    double temperatura;
    double temperaturaajustada;

    void ajustarTemperatura(double temperaturaajustada){
        if (temperaturaajustada < 16) {
            System.err.println("Temperatura mais baixa que o permitido! Ajuste para 16ºC");
            temperatura=16;
        } else if (temperaturaajustada > 28) {
            System.err.println("Temperatura mais alto que o permitido! Ajuste para 28ºC");
            temperatura=28;
        } else {
            temperatura = temperaturaajustada;
        }

    }
}