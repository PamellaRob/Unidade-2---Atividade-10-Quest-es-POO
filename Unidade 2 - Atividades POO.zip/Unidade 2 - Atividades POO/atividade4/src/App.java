public class App {
    public static void main(String[] args) throws Exception {
        ArCondicionado arcondicionado = new ArCondicionado();

        arcondicionado.ajustarTemperatura(12);

        System.err.println("Temperatura ajustada para: " + arcondicionado.temperatura + "ºC");
    }
}
