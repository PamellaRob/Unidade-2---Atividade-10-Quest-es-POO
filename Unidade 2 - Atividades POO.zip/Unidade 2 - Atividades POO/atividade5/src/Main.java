public class Main {
    public static void main(String[] args) throws Exception {
        disciplina poo = new disciplina();

        poo.notaFinal = 9.0;
        poo.presenca = 70;

        poo.resultadoDaAnalise();

        System.err.println("Nota: " + poo.notaFinal);
        System.err.println("Presença: " + poo.presenca + "%");
    }
}
