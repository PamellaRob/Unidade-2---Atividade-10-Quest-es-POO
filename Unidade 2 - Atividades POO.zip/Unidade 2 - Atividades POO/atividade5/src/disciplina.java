public class disciplina {
    double notaFinal; // (0-10)
    int presenca; // (0-100%)

    void resultadoDaAnalise(){
        if (notaFinal >= 7 && presenca >= 75) {
            System.out.println("O aluno está aprovado!");
        } else {
            System.out.println("O aluno está reprovado!");
        }
    }
    
}