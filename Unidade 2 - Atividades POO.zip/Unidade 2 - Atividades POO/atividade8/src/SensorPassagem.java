public class SensorPassagem {
    int id;
    boolean estaAtivo;
}
