public class Main {
    public static void main(String[] args) throws Exception {
        Semaforo semaforo = new Semaforo();
        semaforo.cor = "Vermelho";

        Via via = new Via();
        via.nome = "Avenida Valter Alencar";
        via.fluxoVeiculos = 20;

        SensorPassagem sensor = new SensorPassagem();
        sensor.id=5;
        sensor.estaAtivo=true;

        Veiculo ambulancia = new Veiculo();
        ambulancia.placa = "TRPI - 0909";
        ambulancia.tipo = 1; // 1 = Ambulância

        ControladorCentral controlador = new ControladorCentral();

        controlador.verificarPrioridade(ambulancia, semaforo, sensor, via);

        }
}
