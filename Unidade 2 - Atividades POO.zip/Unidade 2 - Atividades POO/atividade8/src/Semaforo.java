public class Semaforo {
    String cor;

    void trocar(){
        cor = "Verde";
    }
}
