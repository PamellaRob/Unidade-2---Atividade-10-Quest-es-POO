public class Via {
    String nome;
    int fluxoVeiculos;
}
