public class Veiculo {
    String placa;
    int tipo; // 1 = Ambulânica
}
