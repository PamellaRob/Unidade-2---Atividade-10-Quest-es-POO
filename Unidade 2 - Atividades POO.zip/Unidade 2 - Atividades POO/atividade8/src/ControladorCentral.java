public class ControladorCentral {

    void verificarPrioridade (Veiculo veiculo, Semaforo semaforo, SensorPassagem sensor, Via via){
     if (veiculo.tipo == 1) {
        if (semaforo.cor == "Vermelho") {
            semaforo.trocar();
            System.out.println("Prioridade detectada para " + veiculo.placa + " na " + via.nome + ". Sinal alterado para Verde.");
    }
}
}
}
