public class Main {
    public static void main(String[] args) throws Exception {
        Produto produto = new Produto();
        produto.nome= "Processador";
        produto.pontoCritico = 10;
        produto.precoUnitario = 630.70;

        Estoque estoque = new Estoque();
        estoque.quantidadeAtual = 15;

        Fornecedor fornecedor = new Fornecedor();
        fornecedor.nomeEmpresa = "Pichau";
        fornecedor.tempoEntregaDias= 7;

        GerenteLogistico gerente = new GerenteLogistico();

        //Simulação de venda de 7 unidades
        estoque.reduzirEstoque(7);

        gerente.verificarEstoque(produto, estoque, fornecedor);
        
    }
}
