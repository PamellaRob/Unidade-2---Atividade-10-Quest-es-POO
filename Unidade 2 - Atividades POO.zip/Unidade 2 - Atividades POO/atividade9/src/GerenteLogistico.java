public class GerenteLogistico {
    void verificarEstoque (Produto produto, Estoque estoque, Fornecedor fornecedor){
        PedidoCompra pedido = new PedidoCompra();
        pedido.idPedido = 1;
        pedido.status = "Enviado";

        fornecedor.enviarProdutos(60);

        System.out.println("Estoque Crítico detectado para " + produto.nome + ". Gerando Pedido de Compra com o fornecedor " + fornecedor.nomeEmpresa + ". Status: " + pedido.status + ".");
    }
    
}