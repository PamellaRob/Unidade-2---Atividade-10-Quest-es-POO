public class PedidoCompra {
    int idPedido;
    String status;
}
