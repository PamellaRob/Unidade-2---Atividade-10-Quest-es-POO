public class Fornecedor {
    String nomeEmpresa;
    int tempoEntregaDias;

    void enviarProdutos(int qtd){
        System.out.println("Fornecedor enviando " + qtd + " produtos");
    }
}
