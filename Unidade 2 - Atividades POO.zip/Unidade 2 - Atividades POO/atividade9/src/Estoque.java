public class Estoque {
    int quantidadeAtual;
    String localizacaoCorredor;

    void reduzirEstoque (int qtd){
        quantidadeAtual = quantidadeAtual - qtd;
    }

    void adicionarEstoque(int qtd){
        quantidadeAtual = quantidadeAtual + qtd;
    }
}
