public class Produto {
    String nome;
    double precoUnitario;
    int pontoCritico;
}
